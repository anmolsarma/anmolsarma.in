package com.huawei.testndk;

class Constants {
    static final String TAG = "HiSync";
    static final int HUAWEI_CMP_ID = 0xF27D;
    static final byte[] STROBE_MARKER = {(byte) 0x88, 0x01, 0x01};
}
