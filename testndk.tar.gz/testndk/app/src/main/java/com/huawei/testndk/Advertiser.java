package com.huawei.testndk;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.AdvertisingSetParameters;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.support.annotation.NonNull;
import android.util.Log;

import static com.huawei.testndk.Constants.HUAWEI_CMP_ID;
import static com.huawei.testndk.Constants.STROBE_MARKER;
import static com.huawei.testndk.Constants.TAG;

public class Advertiser {
    private BluetoothLeAdvertiser mAdvertiser;
    private AdvertiseSettings mSettings;
    private AdvertiseCallback mCallback;

    Advertiser(@NonNull byte[] payload) {
        mAdvertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();
        new AdvertisingSetParameters.Builder();
        AdvertiseSettings.Builder settingsBuilder = new AdvertiseSettings.Builder();
        settingsBuilder.setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER);
        settingsBuilder.setTimeout(0);
        settingsBuilder.setConnectable(true);
        mSettings = settingsBuilder.build();
        mCallback = new HiSyncAdvertiseCallback();

        setData(payload);
    }

    public void setData(byte[] payload) {
        byte[] pdu = new byte[STROBE_MARKER.length + payload.length];
        System.arraycopy(STROBE_MARKER, 0, pdu, 0, STROBE_MARKER.length);
        System.arraycopy(payload, 0, pdu, STROBE_MARKER.length, payload.length);
        AdvertiseData.Builder dataBuilder = new AdvertiseData.Builder();
        dataBuilder.addManufacturerData(HUAWEI_CMP_ID, pdu);

        mAdvertiser.stopAdvertising(mCallback);
        mAdvertiser.startAdvertising(mSettings, dataBuilder.build(), mCallback);

    }

    private class HiSyncAdvertiseCallback extends AdvertiseCallback {

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.d(TAG, "Advertising failed");
        }

        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.d(TAG, "Advertising successfully started");
        }

    }
}
