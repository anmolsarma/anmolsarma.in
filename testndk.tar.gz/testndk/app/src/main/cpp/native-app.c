/*
 * Placeholder for Native Application using iSync.
 *
 */
#include <stdint.h>
#include <android/log.h>
//#include "isync_pal.h"

#include "isync_appexp.h"

int service_notification(const int id, device_t *dev,
                         const uint8_t *buf, const size_t len)
{
    __android_log_write(ANDROID_LOG_DEBUG, "HiSync","GOT SERVICE NOTIFICATION:\n");
    return 0;
}

void app_main(void)
{
    int ret;


    isync_set_devid("myapp-dev");
    isync_set_devact("myuser@huawei.com");
    isync_set_devtype(0x1234);

    ret = isync_init();
    if(ret)
    {
        __android_log_write(ANDROID_LOG_DEBUG, "HiSync","isync_init failed");
        return;
    }
    __android_log_write(ANDROID_LOG_DEBUG, "HiSync","isync init success\n");

    isync_service_observer(service_notification);

    ret = isync_start_service(ID_CLIPBOARD);
    if(ret)
    {
        __android_log_write(ANDROID_LOG_DEBUG, "HiSync","start_service failed\n");
        return;
    }
#if 0
    ret = isync_start_service(10);
    ret = isync_start_service(11);
    ret = isync_start_service(12);
    ret = isync_start_service(13);
    ret = isync_start_service(14);

    {
        int i;
        for(i=10; i< 15; i++)
        {
            ret = isync_stop_service(i);
        }
    }
#endif

//    pause();
//    return 1;
}

//int app_scan_callback(const char *addrstr, size_t len) {
//    __android_log_write(ANDROID_LOG_DEBUG, "HiSync: Received", addrstr);
//    return 0;
//}

//void app_main() {
//    isync_advertise(0, 0);
//    isync_scan(app_scan_callback);
//}

