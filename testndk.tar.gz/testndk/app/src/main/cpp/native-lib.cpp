/*
 * iSync Platform Abstraction Layer implementation for Android
 *
 */

#include <jni.h>
#include <string>
#include <android/log.h>

#include "isync_pal.h"

extern "C" {

static JNIEnv *g_JNIenv = NULL;
static jobject g_AdvertiserInstance = NULL;
static jobject g_ScannerInstance = NULL;
static scan_notify_cb g_ScanNotifyCB = NULL;

/* Invoked by the JVM when this library is loaded.
 * We save the JNIEnv pointer to use it for calling Java APIs outside the JVM context. */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {

    vm->GetEnv((void **) &g_JNIenv, JNI_VERSION_1_6);
    __android_log_write(ANDROID_LOG_DEBUG, "HiSync", "OnLoad");
    return JNI_VERSION_1_6;
}

/* Start advertising the device.
 * For now, arguments are only placeholders and we advertise dummy data. */
int isync_advertise(const uint32_t rid, const uint16_t devtype) {

    jclass advertiserClass = g_JNIenv->FindClass("com/huawei/testndk/Advertiser");
    jmethodID advertiserConstructor = g_JNIenv->GetMethodID(advertiserClass, "<init>", "([B)V");

    jbyte a[] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    jbyteArray ret = g_JNIenv->NewByteArray(11);
    g_JNIenv->SetByteArrayRegion(ret, 0, 11, a);

    jobject advertiserInstance = g_JNIenv->NewObject(advertiserClass, advertiserConstructor, ret);
    g_JNIenv->DeleteLocalRef(ret);
    g_AdvertiserInstance = g_JNIenv->NewGlobalRef(advertiserInstance);

    return 0;
}

//TODO: Handle payload
/* Callback invoked by Java Scanner to deliver an advertisement message.
 * We simply pass the message to the scan callback registered by iSync. */
JNIEXPORT void JNICALL
Java_com_huawei_testndk_Scanner_resultCallback(JNIEnv *env, jobject, jstring addr,
                                               jbyteArray payload) {

    const char *addrStr = env->GetStringUTFChars(addr, 0);
    g_ScanNotifyCB(addrStr, strlen(addrStr));

}

/* Start scanning for advertisements. */
int isync_scan(scan_notify_cb callback) {
    g_ScanNotifyCB = callback;

    jclass scannerClass = g_JNIenv->FindClass("com/huawei/testndk/Scanner");
    jmethodID scannerConstructor = g_JNIenv->GetMethodID(scannerClass, "<init>", "()V");
    jobject scannerInstance = g_JNIenv->NewObject(scannerClass, scannerConstructor);
    g_ScannerInstance = g_JNIenv->NewGlobalRef(scannerInstance);

    return 0;
}

void isync_adv_cleanup() {
    return;
}

void isync_scan_cleanup() {
    return;
}

void app_main();

// Place holder entry point for native app
JNIEXPORT void JNICALL
Java_com_huawei_testndk_MainActivity_appKickoff(JNIEnv *env, jobject) {
    app_main();
}

JNIEXPORT jbyteArray JNICALL
Java_com_huawei_testndk_GattServer_gattNativeCallback(JNIEnv *env, jobject, jstring addr) {

    jbyte a[] = {0x42, 0x43, 0x44, 0x45, 0x46};
    jbyteArray ret = env->NewByteArray(5);
    env->SetByteArrayRegion(ret, 0, 5, a);
    return ret;

}

}



