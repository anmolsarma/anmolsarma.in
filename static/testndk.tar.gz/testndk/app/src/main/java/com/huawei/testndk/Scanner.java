package com.huawei.testndk;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.util.Log;

import java.util.Arrays;
import java.util.List;

import static com.huawei.testndk.Constants.HUAWEI_CMP_ID;
import static com.huawei.testndk.Constants.STROBE_MARKER;
import static com.huawei.testndk.Constants.TAG;

public class Scanner  {

    Scanner() {

        BluetoothLeScanner scanner = BluetoothAdapter.getDefaultAdapter().getBluetoothLeScanner();
        ScanSettings scanSettings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build();
        ScanFilter filter = new ScanFilter.Builder().build();
        scanner.startScan(Arrays.asList(filter), scanSettings, new HiSyncScanCallback());
    }

    private native void resultCallback(String addr, byte[] payload);

    private class HiSyncScanCallback extends ScanCallback {

        private byte[] parseStrobe(byte[] payload) {
            if (Arrays.equals(STROBE_MARKER, Arrays.copyOfRange(payload, 0, STROBE_MARKER.length))) {
                return Arrays.copyOfRange(payload, STROBE_MARKER.length, payload.length);
            }
            return null;
        }

        private void handleScanResult(ScanResult result) {
            ScanRecord record = result.getScanRecord();
            if (record != null) {
                byte[] msd = record.getManufacturerSpecificData(HUAWEI_CMP_ID);
                if (msd == null)
                    return;
                byte[] strobe = parseStrobe(msd);
                StringBuilder sb = new StringBuilder();
                if (strobe == null)
                    return;
                for (byte b : strobe) {
                    sb.append(String.format("%02X ", b));
                }
                String peerAddr = result.getDevice().getAddress();
                resultCallback(peerAddr, strobe);
                Log.d(TAG, "Discovery " + sb + " from " + peerAddr);
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);

            for (ScanResult result : results) {
                handleScanResult(result);
            }
        }

        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            handleScanResult(result);

        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Log.d(TAG, "Scan failed with error: " + errorCode);
        }
    }
}
