#pragma once

int  isync_service_init(void);
void isync_serviceall_cleanup(void);
